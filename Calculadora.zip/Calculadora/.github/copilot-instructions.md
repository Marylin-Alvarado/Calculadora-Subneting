<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

Este proyecto es una calculadora Flutter compatible con web y Android. Debe incluir suma, resta, multiplicación y división.
