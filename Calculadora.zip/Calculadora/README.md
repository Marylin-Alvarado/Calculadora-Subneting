# Calculadora Flutter

Este proyecto es una calculadora desarrollada en Flutter compatible con web y Android. Permite realizar operaciones de suma, resta, multiplicación y división.

## ¿Cómo ejecutar?

1. Abre este proyecto en Android Studio o VS Code.
2. Ejecuta en modo web usando:
   ```
   flutter run -d chrome
   ```
   O ejecuta en un emulador Android usando:
   ```
   flutter run -d <id_del_emulador>
   ```

## Funcionalidades
- Suma
- Resta
- Multiplicación
- División

---

> Proyecto generado automáticamente.
